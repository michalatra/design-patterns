//
// Created by XPS-15 on 17.05.2022.
//

#include <iostream>
#include "ClientSearchBox.h"

void ClientSearchBox::renderSearchBox() {
    std::cout<<"Rendering client search box\n";
}

void ClientSearchBox::handleSearch(std::string input) {
    std::cout<<"[CLIENT SEARCH BOX] Searching input: "<<input<<"...\n";
}
