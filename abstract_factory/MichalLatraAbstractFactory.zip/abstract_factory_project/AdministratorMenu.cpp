//
// Created by XPS-15 on 17.05.2022.
//

#include <iostream>
#include "AdministratorMenu.h"

void AdministratorMenu::renderMenu() {
    std::cout<<"Rendering admin menu\n";

}

void AdministratorMenu::handleCommand(std::string command) {
    std::cout<<"[ADMIN MENU] Handling command: "<<command<<"...\n";

}
