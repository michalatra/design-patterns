//
// Created by XPS-15 on 17.05.2022.
//

#include <iostream>
#include "ClientMenu.h"

void ClientMenu::renderMenu() {
    std::cout<<"Rendering client menu\n";

}

void ClientMenu::handleCommand(std::string command) {
    std::cout<<"[CLIENT MENU] Handling command: "<<command<<"...\n";
}
