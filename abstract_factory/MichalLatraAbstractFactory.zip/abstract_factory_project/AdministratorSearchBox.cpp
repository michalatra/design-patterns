//
// Created by XPS-15 on 17.05.2022.
//

#include "AdministratorSearchBox.h"
#include <iostream>

void AdministratorSearchBox::renderSearchBox() {
    std::cout<<"Rendering admin search box\n";
}

void AdministratorSearchBox::handleSearch(std::string input) {
    std::cout<<"[ADMIN SEARCH BOX] Searching input: "<<input<<"...\n";
}
