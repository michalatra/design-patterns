//
// Created by micha on 09.05.2022.
//

#ifndef FACTORY_METHOD_PROJECT_MESSAGE_H
#define FACTORY_METHOD_PROJECT_MESSAGE_H


class Message {
public:
    virtual void showContent() = 0;
};


#endif //FACTORY_METHOD_PROJECT_MESSAGE_H
