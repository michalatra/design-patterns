//
// Created by XPS-15 on 17.05.2022.
//

#ifndef PROTOTYPE_PROJECT_PROTOTYPE_H
#define PROTOTYPE_PROJECT_PROTOTYPE_H


class Prototype {
public:
    virtual Prototype* clone() = 0;
};


#endif //PROTOTYPE_PROJECT_PROTOTYPE_H
