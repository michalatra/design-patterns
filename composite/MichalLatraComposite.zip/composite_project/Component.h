//
// Created by XPS-15 on 17.05.2022.
//

#ifndef COMPOSITE_PROJECT_COMPONENT_H
#define COMPOSITE_PROJECT_COMPONENT_H


class Component {
public:
    virtual void show() = 0;
};


#endif //COMPOSITE_PROJECT_COMPONENT_H
