#include <iostream>
#include "SomeFancyApp.h"

int main() {
    SomeFancyApp app = SomeFancyApp();

    app.run();

    return 0;
}
