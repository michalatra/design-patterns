//
// Created by XPS-15 on 10.05.2022.
//

#include "CameraDecorator.h"

CameraDecorator::CameraDecorator(ICamera *wrappee) : wrappee(wrappee) {}

